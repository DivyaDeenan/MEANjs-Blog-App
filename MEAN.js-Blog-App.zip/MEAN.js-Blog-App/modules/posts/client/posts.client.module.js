(function (app) {
  'use strict';

  app.registerModule('posts');
}(ApplicationConfiguration));
